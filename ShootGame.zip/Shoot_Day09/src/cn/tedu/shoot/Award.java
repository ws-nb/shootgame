package cn.tedu.shoot;

public interface Award {
	public int DOUBLE_FIRE = 0;
	public int LIFE = 1;
	public int getType();
}
