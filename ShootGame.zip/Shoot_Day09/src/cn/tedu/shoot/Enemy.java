package cn.tedu.shoot;

public interface Enemy {
	public int getScore();
}
